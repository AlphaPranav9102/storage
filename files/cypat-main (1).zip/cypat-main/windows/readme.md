# TO DO

### Account Management
- Delete users who aren't supposed to be there
- Demote admins who aren't supposed to be admins
- Give users who are supposed to be admins admin perms

### Security Policy
- Add stuff here
