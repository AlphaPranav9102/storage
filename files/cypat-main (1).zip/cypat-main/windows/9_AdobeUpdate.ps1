﻿$name = "AcroRd32.exe"
$searchPath = Get-ChildItem -Path c:\ -Recurse $name | Select-Object -Property FullName | foreach{$_.FullName}
if (!$searchPath) {
    Write-Host("$Name Does not exist..Script ending")
}else{
    if ($searchPath -is [system.array]) {
        $path = $searchPath[0]
    }else {
        $path = $searchPath
    }
    $cV = (Get-Item $path).VersionInfo
    $FileVersion = ("{0}.{1}.{2}" -f $cV.FileMajorPart, 
        $cV.FileMinorPart, 
        $cV.FileBuildPart)
    Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
    if (!(Test-Path -Path "C:\Program Files\PackageManagement\ProviderAssemblies\nuget")) {Find-PackageProvider -Name 'Nuget' -ForceBootstrap -IncludeDependencies}
    if (!(Get-Module -ListAvailable -Name Evergreen)) {Install-Module Evergreen -Force | Import-Module Evergreen}
    Update-Module Evergreen
    $Evergreen = Get-AdobeAcrobatReaderDC
    $Version = $Evergreen.Version[0]
    if ([version]$FileVersion -lt [version]$Version) {
        $workdir = "c:\installer\"
        If (Test-Path -Path $workdir -PathType Container){ 
            Write-Host "$workdir already exists" -ForegroundColor Red}
        ELSE{ 
            New-Item -Path $workdir  -ItemType directory
        }
        $source = "http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/" + $Version.Replace(".","") + "/AcroRdrDC" + $Version.Replace(".","") + "_en_US.exe"
        $destination = "$workdir\" + $name
        if (Get-Command 'Invoke-Webrequest'){
            Invoke-WebRequest $source -OutFile $destination
        }else{
             $WebClient = New-Object System.Net.WebClient
             $webclient.DownloadFile($source, $destination)
        }
        Start-Process -FilePath $destination -ArgumentList "/S"
        Start-Sleep -s 35
        $new_version = (Get-Item $path).VersionInfo
        $NewFileVersion = ("{0}.{1}.{2}" -f $new_version.FileMajorPart, 
        $new_version.FileMinorPart, 
        $new_version.FileBuildPart)
        Write-Host "Adobe Acrobat Reader DC is now version: $NewFileVersion"
    }else {
        Write-Host "Adobe Acrobat Reader DC is already the latest version: $FileVersion"
    }
}