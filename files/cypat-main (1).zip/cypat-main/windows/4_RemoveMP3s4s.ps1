﻿# Remove-Item -path C:\Users\ -include *.mp3 -recurse
# Remove-Item -path C:\Users\ -include *.mp4 -recurse

Write-Host "Hello"