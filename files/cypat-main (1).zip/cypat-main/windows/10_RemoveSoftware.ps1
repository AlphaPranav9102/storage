#comment out after run once
Remove-Item "C:\Program Files\BitComet\BitComet.exe" -Force
Remove-Item "C:\Program Files\SPEEDbit Video Downloader\Converter.exe" -Force
Remove-Item "C:\Windows\nc.exe" -Force
Remove-Item "C:\Share\secret.txt" -Force
Remove-Item "C:\Program Files\Intermedia Software\Helium 9\helium9.exe" -Force
Remove-Item "C:\Program Files\Nexus Radio\Nexus Radio.exe" -Force
Remove-Item "C:\Program Files\TVexe\TVexe TV HD.exe" -Force

<#
$name = Read-Host -Prompt "Enter name of software"
$name += ".exe"
$searchPath = Get-ChildItem -Path c:\ -Recurse $name | Select-Object -Property FullName | foreach{$_.FullName}
if ($searchPath -is [system.array]) {
    $path = $searchPath[0]
}else {
    $path = $searchPath
}
Remove-Item $Path -Force
Write-Host "Deleted $name from $path"
#>