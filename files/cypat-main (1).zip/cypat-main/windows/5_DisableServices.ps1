﻿Set-Service -Name ftpsvc -StartupType Disabled #Microsoft FTP Service
Get-Service -Name ftpsvc | Stop-Service -Force
Set-Service -Name Spooler -StartupType Disabled #Print Spooler
Get-Service -Name Spooler | Stop-Service -Force
Set-Service -Name RasAuto -StartupType Disabled #Remote Access Auto Connection Manager
Get-Service -Name RasAuto | Stop-Service -Force
Set-Service -Name RasMan -StartupType Disabled #Remote Access Connection Manager
Get-Service -Name RasMan | Stop-Service -Force
Set-Service -Name SessionEnv -StartupType Disabled #Remote Desktop Configuration
Get-Service -Name SessionEnv | Stop-Service -Force
Set-Service -Name TermService -StartupType Disabled #Remote Desktop Services
Get-Service -Name TermService | Stop-Service -Force
Set-Service -Name UmRdpService -StartupType Disabled #Remote Desktop Services UserMode
Get-Service -Name UmRdpService | Stop-Service -Force
Set-Service -Name RemoteRegistry -StartupType Disabled #Remote Registry
Get-Service -Name RemoteRegistry | Stop-Service -Force
#Get-Service -Name LanmanServer | Stop-Service -Force #Server
Set-Service -Name SSDPSRV -StartupType Disabled #SNMP Trap
Get-Service -Name SSDPSRV | Stop-Service -Force
Set-Service -Name lmhosts -StartupType Disabled #SSDP Discovery
Get-Service -Name lmhosts | Stop-Service -Force
Set-Service -Name TapiSrv -StartupType Disabled #Telephony
Get-Service -Name TapiSrv | Stop-Service -Force
Set-Service -Name TlntSvr -StartupType Disabled #Telnet
Get-Service -Name TlntSvr | Stop-Service -Force
Set-Service -Name upnphost -StartupType Disabled #UPnP Device Host
Get-Service -Name upnphost | Stop-Service -Force
Set-Service -Name W3SVC -StartupType Disabled #Windows Web Publishing Service
Get-Service -Name W3SVC | Stop-Service -Force
#Enable 'Windows Event Log" service
Set-Service -Name 'EventLog' -StartupType Automatic
Set-Service -Name 'EventLog' -Status Running
#Enable 'Windows Update" service
Set-Service -Name 'wuauserv' -StartupType Automatic
Set-Service -Name 'wuauserv' -Status Running