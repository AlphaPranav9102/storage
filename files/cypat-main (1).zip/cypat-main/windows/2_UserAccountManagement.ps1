﻿New-Item "C:\Users\desiredusers.txt"
Invoke-Item "C:\Users\desiredusers.txt"
$continue = Read-Host -Prompt "Enter y to continue"
if ($continue -eq "y"){
    $users = "C:\Users\desiredusers.txt"
    $parse = Get-Content -Path $users
    $desired_users = @()
    $desired_admins = @()
    $actual_users = @()
    $actual_admins = @()
    $newpass = @("NPLBA%w%gx8nAh4L", "aR#U^^eX2Nu%f-2_", "JHa9FAY^r8Q^48KT", "PZ=Ud68x-_xqjXpd", "az23kwvjZ5%pFQ9W", "7qZF]]Z*-nN9kAuD", "D6bfv>U_ct;D.3TM", "NJ*r)6)4.3vZ9T'L", "jMXd3Bxk@.&9p*92", "WCsPuGJS8mXG{`eL", "AVJZE+9@`(VMa[BA", "jqdNcv*>bS7Qux#}", "hLUC#8`DhF]m\h[r", "z=}X%BnT!2WJ4{tGg", "g(*:9TGvv.sAG_Yc", "Wm+zpYjw58GH8hFZ", "w4N8wR<zDTgm>UX_", "UHF43suErs5z>8Wf", "KB6zC>n7,r?M`B", "8@T6W,hb[JJnNY;3", "fC<Z_/aU5W/`U(x9", "bcPT+~.28Y7`<H/3", "58C\Gr*UwLBL:5Jn", "yK_9AtCdP`gH&qUL", "U{NJ9@YrE6vz#-C3")
    $passparse = 0
    
    #desired_users (only the authorized users, not admins)
    #desired_admins
    [bool] $adminoruser = $true
    $parse | foreach {
        $line = $_
        if ($line -eq "Authorized Users:" ) {
            $adminoruser = $false
        }
        if (!($line -eq "Authorized Users:") -and !($line -eq "Authorized Administrators:")){
            if ($adminoruser -eq $true){
                if (!($line.Contains("password")) -and !($line.Contains("PW"))) {
                    if ($line.Contains("(")){
                        $posofspace = $line.IndexOf(" ")
                        $goduser = $line.Substring(0,$posofspace)
                        $desired_admins += $line.Substring(0,$posofspace)
                    } else {
                        $desired_admins += $line
                    }
                }
            } else {
                $desired_users += $line
            }
        }
    }

    #$actual_users
    $(Get-LocalGroupMember -Group "Users" | Select-Object -ExpandProperty Name) | foreach {
        $temp = $_
        $posofslash = $temp.IndexOf("\")
        if ($temp.Contains("DESKTOP")){
            $actual_users += $temp.Substring($posofslash+1)
        }
    }

    #$actual_admins
    $(Get-LocalGroupMember -Group "Administrators" | Select-Object -ExpandProperty Name) | foreach {
        $temp = $_
        $posofslash = $temp.IndexOf("\")
        if ($temp.Contains("DESKTOP") -and !($temp.Contains("Administrator"))){
            $actual_admins += $temp.Substring($posofslash+1)
        }
    }

    #Creates new strong passwords for everyone except goduser
    $actual_users | foreach{
        $current_user = $_
        if (!($current_user -eq $goduser)){
                $UserAccount = Get-LocalUser -Name $current_user
                $plaintext = $newpass[$passparse]
                $password = ConvertTo-SecureString $plaintext -AsPlainText -Force
                $UserAccount | Set-LocalUser -Password $password
                "Created password for $current_user : $plaintext"
                $passparse += 1
        }
    }
    #Removes all users who aren't supposed to be admins from the admin group
        #Code logic: for each person in the actual admins list, if they are not in the desired admins list, then they are removed
    $actual_admins | foreach{
        $current_user = $_
        if (!($desired_admins.Contains($current_user))){
            Remove-LocalGroupMember -Group "Administrators" -Member $current_user
            "Removed $current_user from ADMIN group"
        }
    }
    #Adds default users to admins if necessary
        #Brain logic: if you look though the desired admin group and see that someone from that group is not in the current admin group, add that person to the current admin group
        #Code logic: for each person in the desired admins list, if they are not in the actual admins list, add them to the list
    $desired_admins | foreach{
        $current_user = $_
        if (!($actual_admins.Contains($current_user))){
            Add-LocalGroupMember -Group "Administrators" -Member $current_user
            "Added $current_user to ADMIN group"
        }
    }
    #Deletes all unauthorized users
        #Brain logic: Unauthorized user: he's in the actual list, but not in the desired list
        #Code logic: for each person in the actual users list (all current users), if they are not in the desired users list or the desried admins list, then they are removed
    $actual_users | foreach{
        $current_user = $_
        if (!($desired_users.Contains($current_user))){
             if (!($desired_admins.Contains($current_user))){
                Remove-LocalUser -Name $current_user
                "Removed unauthorized user: $current_user"
             }   
        }
    }
    Remove-Item -Path "C:\Users\desiredusers.txt"
    "Deleted desiredusers.txt"
}