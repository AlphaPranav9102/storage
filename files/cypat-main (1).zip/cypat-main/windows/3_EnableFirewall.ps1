﻿Set-Service -Name MpsSvc -StartupType Automatic
Set-Service -Name MpsSvc -Status Running
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True