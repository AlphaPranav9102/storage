﻿[bool] $win = $false
Import-Module ActiveDirectory
if (Get-Module -ListAvailable -Name "ActiveDirectory") {
    $win = $false
} 
else {
    $win = $true
}

New-Item "C:\Users\desiredusers.txt"
Invoke-Item "C:\Users\desiredusers.txt"
$continue = Read-Host -Prompt "Enter y to continue"
if ($continue -eq "y"){
    $users = "C:\Users\desiredusers.txt"
    $parse = Get-Content -Path $users
    $desired_users = @()
    $desired_admins = @()
    $actual_users = @()
    $actual_admins = @()
    $given_name = @()
    $newpass = @("NPLBA%w%gx8nAh4L", "aR#U^^eX2Nu%f-2_", "JHa9FAY^r8Q^48KT", "PZ=Ud68x-_xqjXpd", "az23kwvjZ5%pFQ9W", "7qZF]]Z*-nN9kAuD", "D6bfv>U_ct;D.3TM", "NJ*r)6)4.3vZ9T'L", "jMXd3Bxk@.&9p*92", "WCsPuGJS8mXG{`eL", "AVJZE+9@`(VMa[BA", "jqdNcv*>bS7Qux#}", "hLUC#8`DhF]m\h[r", "z=}X%BnT!2WJ4{tGg", "g(*:9TGvv.sAG_Yc", "Wm+zpYjw58GH8hFZ", "w4N8wR<zDTgm>UX_", "UHF43suErs5z>8Wf", "KB6zC>n7,r?M`B", "8@T6W,hb[JJnNY;3", "fC<Z_/aU5W/`U(x9", "bcPT+~.28Y7`<H/3", "58C\Gr*UwLBL:5Jn", "yK_9AtCdP`gH&qUL", "U{NJ9@YrE6vz#-C3")
    $passparse = 0
    
    #desired_users (only the authorized users, not admins)
    #desired_admins
    [bool] $adminoruser = $true
    $parse | foreach {
        $line = $_
        if ($line -eq "Authorized Users:" ) {
            $adminoruser = $false
        }
        if (!($line -eq "Authorized Users:") -and !($line -eq "Authorized Administrators:")){
            if ($adminoruser -eq $true){
                if (!($line.Contains("password")) -and !($line.Contains("PW"))) {
                    if (!($line -eq "")) {
                        if ($line.Contains("(")){
                            $posofspace = $line.IndexOf(" ")
                            $goduser = $line.Substring(0,$posofspace)
                            $desired_admins += $line.Substring(0,$posofspace)
                        } else {
                            $desired_admins += $line
                        }
                    }
                }
            } else {
                $desired_users += $line
            }
        }
    }

    $domainCheck = $false
    if (!($win)){
        $listGroups = Get-ADGroup -filter * | Select-Object Name | Out-String
        if ($listGroups.Contains("Domain Admins") -and $listGroups.Contains("Domain Users")) {
            $domainCheck = $true
            #$actual_admins and $actual_users (domain)
            $(Get-ADUser -Filter {Enabled -eq $true} | Select-Object -ExpandProperty Name) | foreach {
                $temp = $_
                $check = Get-ADUser -Filter 'Name -like $temp' | Select-Object -ExpandProperty GivenName | Out-String
                if ($check.Length -ne 0) {
                    $temp = $check
                    $given_name += $check
                }
                $grplist = Get-ADPrincipalGroupMembership -Identity $temp | Select-Object Name
                if ($grplist -is [system.array]) {
                    $actual_admins += $temp
                } else{
                    $actual_users += $temp
                }
            }
        } else {
            #$actual_users
            $(Get-LocalGroupMember -Group "Users" | Select-Object -ExpandProperty Name) | foreach {
                $temp = $_
                $posofslash = $temp.IndexOf("\")
                if ($temp.Contains($label)){
                    $actual_users += $temp.Substring($posofslash+1)
                }
            }
            #$actual_admins 
            $(Get-LocalGroupMember -Group "Administrators" | Select-Object -ExpandProperty Name) | foreach {
                $temp = $_
                $posofslash = $temp.IndexOf("\")
                if ($temp.Contains($label) -and !($temp.Contains("Administrator"))){
                    $actual_admins += $temp.Substring($posofslash+1)
                }
            }
        }
    } else {
        if ($win){
            $(Get-LocalGroupMember -Group "Administrators" | Select-Object -ExpandProperty Name) | foreach {
                $temp2 = $_
                if ($temp2.Contains("Administrator")) {
                    $label = $temp2.Substring(0, $temp2.IndexOf("Administrator"))
                }
            }
        }
        #$actual_users
        $(Get-LocalGroupMember -Group "Users" | Select-Object -ExpandProperty Name) | foreach {
            $temp = $_
            $posofslash = $temp.IndexOf("\")
            if ($temp.Contains($label)){
                $actual_users += $temp.Substring($posofslash+1)
            }
        }
        #$actual_admins 
        $(Get-LocalGroupMember -Group "Administrators" | Select-Object -ExpandProperty Name) | foreach {
            $temp = $_
            $posofslash = $temp.IndexOf("\")
            if ($temp.Contains($label) -and !($temp.Contains("Administrator"))){
                $actual_admins += $temp.Substring($posofslash+1)
            }
        }
    }
    "Desired users: "
    $desired_users
    "Desired admin: "
    $desired_admins
    "Actual users: "
    $actual_users
    "Actual admin: "
    $actual_admins
    $desired_AdUse = $desired_users + $desired_admins
    "Desired everything: "
    $desired_AdUse
    
    #Creates a new default user if necessary
        #Code logic: for each user in desired users and desired admins, if user not in actual users, create a new user
    $desired_ev = $desired_users + $desired_admins
    $desired_ev | foreach{
        $current_user = $_
        if (!($actual_users.Contains($current_user))){
            New-LocalUser -Name $current_user -NoPassword
            Add-LocalGroupMember -Group "Users" -Member $current_user
            $actual_users += $current_user
            "Created new user: $current_user"
        }
    }

    #Creates new strong passwords for everyone except goduser (DOES NOT ACCOUNT FOR DOMAIN USERS AND ADMINS, ONLY LOCAL)
    $actual_users | foreach{
        $current_user = $_
        if (!$domainCheck){
            if (!($current_user -eq $goduser)){
                $UserAccount = Get-LocalUser -Name $current_user
                $plaintext = $newpass[$passparse]
                $password = ConvertTo-SecureString $plaintext -AsPlainText -Force
                $UserAccount | Set-LocalUser -Password $password
                "Created password for $current_user : $plaintext"
                $passparse += 1
            }
        }
    }

    #Removes all users who aren't supposed to be admins from the admin group
        #Code logic: for each person in the actual admins list, if they are not in the desired admins list, then they are removed
    $actual_admins | foreach{
        $current_user = $_
        if (!($desired_admins.Contains($current_user))){
            if ($domainCheck) {
                Remove-ADGroupMember -Identity "Domain Admins" -Members $current_user -Confirm:$false
            }else {
                Remove-LocalGroupMember -Group "Administrators" -Member $current_user
            }
            "Removed $current_user from ADMIN group"
        }
    }

    #Adds default users to admins if necessary
        #Brain logic: if you look though the desired admin group and see that someone from that group is not in the current admin group, add that person to the current admin group
        #Code logic: for each person in the desired admins list, if they are not in the actual admins list, add them to the list
    $desired_admins | foreach{
        $current_user = $_
        if (!($actual_admins.Contains($current_user))){
            
            if ($domainCheck) {
                Add-ADGroupMember -Identity "Domain Admins" -Members $current_user -Confirm:$false
            }else {
                Add-LocalGroupMember -Group "Administrators" -Member $current_user
            }
            "Added $current_user to ADMIN group"
        }
    }

    #Deletes all unauthorized users
        #Brain logic: Unauthorized user: he's in the actual list, but not in the desired list
        #Code logic: for each person in the actual users list (all current users), if they are not in the desired users list or the desried admins list, then they are removed
    $actual_users | foreach{
        $current_user = $_
        if (!($desired_users.Contains($current_user))){
             if (!($desired_admins.Contains($current_user))){
                Remove-LocalUser -Name $current_user
                "Removed unauthorized user: $current_user"
             }   
        }
    }
    Remove-Item -Path "C:\Users\desiredusers.txt"
    "Deleted desiredusers.txt"
}