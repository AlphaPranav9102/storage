Authorized Administrators:
newt (you)
	password: Abracadabra
tina
	password: nothing
Authorized Users:
queenie
jacob
albus
theseus
