#!/bin/bash

##Enable firewall
sudo ufw enable
