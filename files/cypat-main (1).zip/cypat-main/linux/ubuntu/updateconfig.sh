#!/bin/bash

#update policies
printf "deb http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\ndeb-src http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\n" | sudo tee -a /etc/apt/sources.list
echo "Install updates from configured."

sudo apt-get install unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
clear
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/10periodic
echo "Updates tab configured."
clear