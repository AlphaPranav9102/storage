#!/bin/bash

read -p "Permit users to login to root account? y or n: " ans
case "$ans" in
        n) sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/usr/sbin/nologin' /etc/passwd
           echo "Disabled root login"
        ;;
        y) echo "Root login will be permitted."
        sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/bin/bash' /etc/passwd
esac

no_passwd_users="$(sudo getent shadow | grep '^[^:]*::' | cut -d: -f1)"
read -p "Disable login for users without password? y or n: " ans
if [ "$ans" == "y" ];
then
        for user in $no_passwd_users
        do
	        sudo passwd -l $user
	        echo "disabling $user login"
        done
fi

read -p "Disable login for bin? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l bin
	echo "disabled bin login"
fi

read -p "Disable login for daemon? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l daemon
	echo "disabled daemon login"
fi

read -p "Disable login for sys? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l sys
	echo "disabled sys login"
fi

read -p "Disable login for uucp? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l uucp
	echo "disabled uucp login"
fi

read -p "Disable login for lp? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l lp
	echo "disabled lp login"
fi

read -p "Disable login for adm? y or n: " ans
if [ "$ans" == "y" ];
then
	sudo passwd -l adm
fi