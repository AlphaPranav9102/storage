#!/bin/bash

cp /etc/login.defs ~/Desktop/backupfiles

sudo apt-get install cracklib
clear

#editing pam files for password days
sudo apt-get install libpam-pwquality
sudo sed -i 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS 90/g' /etc/login.defs
sudo sed -i 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS 7/g' /etc/login.defs
sudo sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE 14/g' /etc/login.defs
#setting requirements for password config
cp /etc/security/pwquality.conf ~/Desktop/backupfiles
sudo sed -i '/difok/c\difok = 1' /etc/security/pwquality.conf
sudo sed -i '/minlen/c\minlen = 8' /etc/security/pwquality.conf
sudo sed -i '/minclass/c\minclass = 3' /etc/security/pwquality.conf
sudo sed -i '/maxrepeat/c\maxrepeat = 2' /etc/security/pwquality.conf
sudo sed -i '/dcredit/c\dcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ucredit/c\ucredit = 1' /etc/security/pwquality.conf
sudo sed -i '/lcredit/c\lcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ocredit/c\ocredit = 1' /etc/security/pwquality.conf
#deny after 5 tries and set unlock time 30 minute
printf "auth required pam_tally2.so deny=5 onerr=fail unlock_time=1800" >> /etc/pam.d/common-auth
printf """auth required /lib/security/$ISA/pam_tally.so onerr=fail no_magic_root\naccount required /lib/security/$ISA/pam_tally.so per_user deny=5
no_magic_root reset""" >> /etc/pam.d/system‐auth
echo "Password requirements have been configured"

#ctrl-alt-delete disabled
cp /etc/init/control-alt-delete.conf ~/Desktop/backupfiles
sudo sed -i '/exec/c\exec false' /etc/init/control-alt-delete.conf
echo "Control-Alt-Delete Reboot disabled"

#enable audit policies
sudo apt-get install auditd
auditcl -e 1
echo "Audit policies are set up"

clear