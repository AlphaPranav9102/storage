#!/bin/bash

sudo apt-get purge netcat -y -qq
clear
echo "Netcat and all other instances have been removed."

sudo apt-get purge john -y -qq
clear
echo "John the Ripper has been removed."

sudo apt-get remove nmap
clear
echo "Zenmap and Nmap removed."

sudo apt-get remove wireshark
clear
echo "Wireshark removed."

sudo apt-get purge hydra -y -qq
clear
echo "Hydra has been removed."

sudo apt-get purge aircrack-ng -y -qq
clear
echo "Aircrack-NG has been removed."

sudo apt-get purge fcrackzip -y -qq
clear
echo "FCrackZIP has been removed."

sudo apt-get purge lcrack -y -qq
clear
echo "LCrack has been removed."

sudo apt-get purge ophcrack -y -qq
clear
echo "OphCrack has been removed."

sudo apt-get purge pdfcrack -y -qq
clear
echo "PDFCrack has been removed."

sudo apt-get purge pyrit -y -qq
clear
echo "Pyrit has been removed."

sudo apt-get purge rarcrack -y -qq
clear
echo "RARCrack has been removed."

sudo apt-get purge sipcrack -y -qq
clear
echo "SipCrack has been removed."

sudo apt-get purge irpas -y -qq
clear
echo "IRPAS has been removed."

sudo apt-get purge logkeys -y -qq
clear 
echo "LogKeys has been removed."

sudo apt-get purge zeitgeist -y -qq
clear
echo "Zeitgeist has been removed."

sudo apt-get purge nfs-kernel-server -y -qq
clear
echo "NFS has been removed."

sudo apt-get purge nginx -y -qq
clear
echo "NGINX has been removed."

sudo apt-get purge inetd -y -qq
clear
echo "Inetd (super-server) and all inet utilities have been removed."

sudo apt-get purge vnc4server -y -qq
clear
echo "VNC has been removed."

sudo apt-get purge snmp -y -qq
clear
echo "SNMP has been removed."

sudo apt-get purge kismet
clear
echo "kismet has been removed."

sudo apt-get purge cryptcat
clear
echo "cryptcat has been removed."

sudo apt autoremove
clear
echo "All unnecessary packages have been removed."