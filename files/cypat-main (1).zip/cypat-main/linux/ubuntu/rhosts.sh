#!/bin/bash

for dir in `cat /etc/passwd | egrep -v '(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin") { print $6 }'`; do
  for file in $dir/.rhosts; do
    if [ ! -h "$file" -a -f "$file" ]; then
        read -p "Delete .rhosts file in $dir? y or n: " ans
        if [ "$ans" == "y" ]; then
                echo "Deleted .rhosts file in $dir"
                sudo rm $file
        fi
    fi 
  done 
done