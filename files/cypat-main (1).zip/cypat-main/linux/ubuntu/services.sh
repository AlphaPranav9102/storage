#!/bin/bash

echo "Do you want to remove crontab tasks? y or n: "
read cronYN
if [ "$cronYN" == "y" ];
then
	sudo crontab -r
	echo "Crontab tasks removed."
fi

clear
echo "Does this machine need Samba? y or n: "
read sambaYN
if [ "$sambaYN" == "n" ]; then
	sudo ufw deny netbios-ns
	sudo ufw deny netbios-dgm
	sudo ufw deny netbios-ssn
	sudo ufw deny microsoft-ds
	sudo apt-get purge samba -y -qq
	sudo apt-get purge samba-common -y  -qq
	sudo apt-get purge samba-common-bin -y -qq
	sudo apt-get purge samba4 -y -qq
	echo "netbios-ns, netbios-dgm, netbios-ssn, and microsoft-ds ports have been denied and Samba has been uninstalled.";
fi
if [ "$sambaYN" == "y" ]; then
	sudo ufw allow netbios-ns
	sudo ufw allow netbios-dgm
	sudo ufw allow netbios-ssn
	sudo ufw allow microsoft-ds
	sudo apt-get install samba -y -qq
	sudo apt-get install system-config-samba -y -qq
	echo "Samba has been configured"
fi
clear
echo "Does this machine need FTP? y or n: "
read ftpYN
if [ "$ftpYN" == "n" ]; then
	sudo apt-get purge vsftpd -y -qq
	sudo apt-get remove pure-ftpd
	sudo ufw deny ftp
	sudo ufw deny sftp
	sudo ufw deny saft 
	sudo ufw deny ftps-data 
	sudo ufw deny ftps
	echo "vstfpd has been purged and ftp ports have been blocked on UFW"
fi
if [ "$ftpYN" == "y" ]; then
	sudo ufw allow ftp 
	sudo ufw allow sftp 
	sudo ufw allow saft 
	sudo ufw allow ftps-data 
	sudo ufw allow ftps
	sudo service vsftpd restart
	# Disable anonymous uploads
	sudo sed -i '/^anon_upload_enable/ c\anon_upload_enable no' /etc/vsftpd.conf
	sudo sed -i '/^anonymous_enable/ c\anonymous_enable=NO' /etc/vsftpd.conf
	# FTP user directories use chroot
	sudo sed -i '/^chroot_local_user/ c\chroot_local_user=YES' /etc/vsftpd.conf
	sudo service vsftpd restart
	echo "FTP has been configured"
fi
clear
echo "Does this machine need SSH? y or n: "
read sshYN
if [ "$sshYN" == "n" ]; then
	sudo apt-get purge openssh-server -y -qq
	sudo ufw deny ssh
	echo "Openssh has been purged and its ports have been blocked on UFW"
fi
if [ "$sshYN" == "y" ]; then
	sudo apt-get install openssh-server -y -qq
	sudo ufw allow ssh
	cp /etc/ssh/sshd_config ~/Desktop/backupfiles
	sudo sed -i '/IgnoreRhosts/c\IgnoreRhosts yes' /etc/ssh/sshd_config
	sudo sed -i '/HostbasedAuthentication/c\HostbasedAuthentication yes' /etc/ssh/sshd_config
	sudo sed -i '/Protocol/c\Protocol 2' /etc/ssh/sshd_config
	sudo sed -i '/LogLevel/c\LogLevel INFO' /etc/ssh/sshd_config
	sudo sed -i '/X11Forwarding/c\X11Forwarding no' /etc/ssh/sshd_config
	sudo sed -i '/MaxAuthTries/c\MaxAuthTries 4' /etc/ssh/sshd_config
	sudo sed -i '/PermitRootLogin/c\PermitRootLogin no' /etc/ssh/sshd_config
	sudo sed -i '/PermitEmptyPasswords/c\PermitEmptyPasswords no' /etc/ssh/sshd_config
	sudo sed -i '/PermitUserEnvironment/c\PermitUserEnvironment no' /etc/ssh/sshd_config
	sudo sed -i '/LoginGraceTime/c\LoginGraceTime 60' /etc/ssh/sshd_config
	echo "Password policies have been set"
	echo "Openssh has been installed."
fi
clear
echo "Does this machine need Telnet? y or n: "
read telnetYN
if [ "$telnetYN" == "n" ];then
	sudo ufw deny telnet 
	sudo ufw deny rtelnet 
	sudo ufw deny telnets
	sudo apt-get purge telnet -y -qq
	sudo apt-get purge telnetd -y -qq
	sudo apt-get purge inetutils-telnetd -y -qq
	sudo apt-get purge telnetd-ssl -y -qq
	echo "Telnet ports have been blocked on UFW and it has been purged."
fi
if [ "$telnetYN" == "y" ]; then
	sudo ufw allow telnet 
	sudo ufw allow rtelnet 
	sudo ufw allow telnets
	echo "All telnet ports have been allowed on the firewall."
fi
clear
echo "Does this machine need Mail? y or n: "
read mailYN
if [ "$mailYN" == "n" ]; then
	sudo ufw deny smtp
	sudo ufw deny pop2
	sudo ufw deny pop3
	sudo ufw deny imap2
	sudo ufw deny imaps
	sudo ufw deny pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been blocked on the firewall"
fi
if [ "$mailYN" == "y" ]; then
	sudo ufw allow smtp
        sudo ufw allow pop2
        sudo ufw allow pop3
        sudo ufw allow imap2
        sudo ufw allow imaps
        sudo ufw allow pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been allowed on the firewall"
fi
clear
echo "Does this machine need Printing? y or n: "
read printYN
if [ "$printYN" == "n" ];
then
	sudo ufw deny ipp 
	sudo ufw deny printer 
	sudo ufw deny cups
	echo "ipp, printer, and cups ports have been denied on the firewall."
elif [ "$printYN" == "y" ];
then
	sudo ufw allow ipp 
	sudo ufw allow printer 
	sudo ufw allow cups
	echo "ipp, printer, and cups ports have been allowed on the firewall."
fi
clear
echo "Does this machine need MySQL? y or n: "
read mysqlYN
if [ "$mysqlYN" == "n" ];
then
	sudo apt-get purge mysql -y -qq
	sudo apt-get purge mysql-client-core-5.5 -y -qq
	sudo apt-get purge mysql-client-core-5.6 -y -qq
	sudo apt-get purge mysql-common-5.5 -y -qq
	sudo apt-get purge mysql-common-5.6 -y -qq
	sudo apt-get purge mysql-server -y -qq
	sudo apt-get purge mysql-server-5.5 -y -qq
	sudo apt-get purge mysql-server-5.6 -y -qq
	sudo apt-get purge mysql-client-5.5 -y -qq
	sudo apt-get purge mysql-client-5.6 -y -qq
	sudo apt-get purge mysql-server-core-5.6 -y -qq
	sudo ufw deny ms-sql-s
	sudo ufw deny ms-sql-m
	sudo ufw deny mysql 
	sudo ufw deny mysql-proxy
	echo "MySQL has been removed. ms-sql-s, ms-sql-m, mysql, mysql-proxy have been denied on firewall."
elif [ "$mysqlYN" == "y" ];
then
	sudo ufw allow ms-sql-s 
	sudo ufw allow ms-sql-m 
	sudo ufw allow mysql 
	sudo ufw allow mysql-proxy
	echo "ms-sql-s, ms-sql-m, mysql, mysql-proxy have been allowed on firewall."
fi
clear
echo "Should this machine be a web server? y or n: "
read webYN
if [ "$webYN" == "n" ];
then
	sudo apt-get purge apache2
	sudo ufw deny http
	sudo ufw deny https
	echo "Apache2 has been removed. http and https have been denied on firewall."
elif [ "$mysqlYN" == "y" ];
then
	sudo apt-get install apache2
	sudo ufw allow http
	sudo ufw allow https
	echo "Apache2 has been installed. http and https have been allowed on firewall."
fi
clear
echo "Does this machine need DNS? y or n: "
read dnsYN
if [ "$dnsYN" == "n" ];
then
	sudo apt-get purge bind9
	sudo ufw deny domain
	echo "DNS bind9 has been removed. Domain port has been denied on firewall."
elif [ "$dnsYN" == "y" ];
then
	sudo apt-get install bind9
	sudo ufw allow domain
	echo "DNS bind9 has been installed. domain port has been allowed on firewall."
fi
clear

