Authorized Administrators:
ballen (you)
	password: ir!%West
iwest
	password: JiTTerS
pspivot
	password: thawne25
grodd
	password: ZoLomOn
jwells
	password: quick
Authorized Users:
cramon
hrathaway
jwest
wwest
csnow
lsnart
hallen
ethawne
jgarrick
savitar
nallen
mstein
mrory
hwells
jalbert
