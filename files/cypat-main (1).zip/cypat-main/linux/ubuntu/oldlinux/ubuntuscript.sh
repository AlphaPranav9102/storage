#!/bin/bash

mkdir -p ~/Desktop/backupfiles #done
chmod 777 ~/Desktop/backupfiles

cp /etc/group ~/Desktop/backupfiles
cp /etc/passwd ~/Desktop/backupfiles

desired_admins=() #done
desired_users=()
all_users=()
adminoruser=true
input="readme.txt"
goduser=""
read -p "Have you changed the readme file? y or n: " ans
if [ "$ans" == "y" ]; then
	while IFS= read -r line
	do
	  if [ "$line" == "Authorized Administrators:" ]; then
			adminoruser=true
	  else
			if [ "$line" == "Authorized Users:" ]; then
					adminoruser=false 
			fi
	  fi
	  if [ "$adminoruser" = true ]; then
			if [ "$line" != "Authorized Administrators:" ]; then
					if [[ "$line" != *"password:"* ]]; then
							output=$( echo "$line" |cut -d' ' -f 1 )
							if [[ "$line" == *"("* ]]; then
								goduser="$output"
							fi
							desired_admins+=("$output")
							all_users+=("$output")
					fi
			fi
	  else
			if [ "$line" != "Authorized Users:" ]; then
					desired_users+=("$line")
					all_users+=("$line")
			fi
	  fi
	done < "$input"
	sudo getent passwd | while IFS=: read -r name password uid gid gecos home shell;
	do
	if [ -d "$home" ] && [ "$(stat -c %u "$home")" = "$uid" ]; then
	if [ ! -z "$shell" ] && [ "$shell" != "/bin/false" ] && [ "$shell" !=  "/usr/sbin/nologin" ]; then
			#delete users who aren't supposed to be there
			if [ "$name" != "root" ]; then
			if [[ " ${all_users[*]} " != *" $name "* ]]; then
				echo "Deleting user $name"
				sudo userdel "$name"
			fi
			if [ "$name" != "$goduser" ]; then
				echo "$name:NJr643vZ9TL" | sudo chpasswd
				echo "Changed "$name" password"
			fi
			#admin users who shouldn't be admins but are
			if getent group sudo | grep -q "\b${name}\b"; then
					if [[ " ${desired_admins[*]} " != *" $name "* ]]; then
							echo "Removing $name from sudoer group"
							sudo deluser "$name" sudo
					fi
			fi
			#users who should be admins but are not
			if [[ " ${desired_admins[*]} " == *" $name "* ]]; then
					if getent group sudo | grep -q "\b${name}\b"; then
							continue;
					else
							echo "Giving $name sudo permissions"
							sudo usermod -aG sudo "$name"
					fi
			fi
			fi
	fi
	fi
	done
	read -p "Type the name of the user you want to add (type no if you don't want to add any users): " ans
	if [ "$ans" != "no" ]; then
			echo "Adding user $ans"
			sudo useradd "$ans"
			sudo usermod -p "NJr643vZ9TL" "$ans"
			sudo usermod -U "$ans"
			read -p "Should the user be an admin? y or n: " adminans
			if [ "$adminans" == "y" ]; then
				echo "Making $ans an admin"
				sudo usermod -aG sudo "$ans"
			fi
	fi
	sudo getent passwd | while IFS=: read -r name password uid gid gecos home shell;
	do
	if [ -d "$home" ] && [ "$(stat -c %u "$home")" = "$uid" ]; then
	if [ ! -z "$shell" ] && [ "$shell" != "/bin/false" ] && [ "$shell" !=  "/usr/sbin/nologin" ]; then
	if [ `sudo awk -F ':' '/^'$name':/ {print $2}' /etc/shadow` ] ; then 
	   continue; 
	else 
	   echo "Adding password for $name";
	   echo $name:$name"NJr643vZ9TL" | sudo chpasswd;
	fi
	fi
	fi
	done
fi 

cp /etc/login.defs ~/Desktop/backupfiles #done

#editing pam files for password
sudo apt-get install libpam-pwquality
sudo sed -i 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS 90/g' /etc/login.defs
sudo sed -i 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS 7/g' /etc/login.defs
sudo sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE 14/g' /etc/login.defs

cp /etc/security/pwquality.conf ~/Desktop/backupfiles
sudo sed -i '/difok/c\difok = 1' /etc/security/pwquality.conf
sudo sed -i '/minlen/c\minlen = 8' /etc/security/pwquality.conf
sudo sed -i '/minclass/c\minclass = 3' /etc/security/pwquality.conf
sudo sed -i '/maxrepeat/c\maxrepeat = 2' /etc/security/pwquality.conf
sudo sed -i '/dcredit/c\dcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ucredit/c\ucredit = 1' /etc/security/pwquality.conf
sudo sed -i '/lcredit/c\lcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ocredit/c\ocredit = 1' /etc/security/pwquality.conf

cp /etc/init/control-alt-delete.conf ~/Desktop/backupfiles
sudo sed -i '/exec/c\exec false' /etc/init/control-alt-delete.conf
echo "Control-Alt-Delete Reboot disabled."

#dnoe until here
sudo apt-get install lightdm
dpkg-reconfigure lightdm
clear
cp /etc/lightdm/lightdm.conf.d ~/Desktop/backupfiles
read -p "Disable guest account? y or n: " ans
echo "Creating lightdm.conf.d"
sudo mkdir /etc/lightdm/lightdm.conf.d
case "$ans" in
        y) sudo sh -c 'printf "[Seat:*]\nallow-guest=false\n" >/etc/lightdm/lightdm.conf.d/50-no-guest.conf'
           echo "Guest account disabled (will go into affect on system reboot)"
	;;
        n) echo "Guest account will not be disabled"
esac

#sudo restart lightdm to disable guest account

read -p "Permit users to login to root account? y or n: " ans
case "$ans" in
        n) sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/usr/sbin/nologin' /etc/passwd
           echo "Disabled root login"
        ;;
        y) echo "Root login will be permitted."
        sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/bin/bash' /etc/passwd
esac

echo "Does this machine need UFW? y or n: "
read ufwYN
if [ "$ufwYN" == "y" ]; then
	sudo ufw enable
	sudo ufw deny 1337
fi
if [ "$ufwYN" == "n" ]; then
	sudo ufw disable
fi
clear

echo "Do you want to remove crontab tasks? y or n: "
read cronYN
if [ "$cronYN" == "y" ];
then
	sudo crontab -r
	echo "Crontab tasks removed."
fi

clear
echo "Does this machine need Samba? y or n: "
read sambaYN
if [ "$sambaYN" == "n" ]; then
	sudo ufw deny netbios-ns
	sudo ufw deny netbios-dgm
	sudo ufw deny netbios-ssn
	sudo ufw deny microsoft-ds
	sudo apt-get purge samba -y -qq
	sudo apt-get purge samba-common -y  -qq
	sudo apt-get purge samba-common-bin -y -qq
	sudo apt-get purge samba4 -y -qq
	echo "netbios-ns, netbios-dgm, netbios-ssn, and microsoft-ds ports have been denied and Samba has been uninstalled.";
fi
if [ "$sambaYN" == "y" ]; then
	sudo ufw allow netbios-ns
	sudo ufw allow netbios-dgm
	sudo ufw allow netbios-ssn
	sudo ufw allow microsoft-ds
	sudo apt-get install samba -y -qq
	sudo apt-get install system-config-samba -y -qq
	echo "Samba has been configured"
fi
clear
echo "Does this machine need FTP? y or n: "
read ftpYN
if [ "$ftpYN" == "n" ]; then
	sudo apt-get purge vsftpd -y -qq
	sudo apt-get remove pure-ftpd
	sudo ufw deny ftp
	sudo ufw deny sftp
	sudo ufw deny saft 
	sudo ufw deny ftps-data 
	sudo ufw deny ftps
	echo "vstfpd has been purged and ftp ports have been blocked on UFW"
fi
if [ "$ftpYN" == "y" ]; then
	sudo ufw allow ftp 
	sudo ufw allow sftp 
	sudo ufw allow saft 
	sudo ufw allow ftps-data 
	sudo ufw allow ftps
	sudo service vsftpd restart
	# Disable anonymous uploads
	sudo sed -i '/^anon_upload_enable/ c\anon_upload_enable no' /etc/vsftpd.conf
	sudo sed -i '/^anonymous_enable/ c\anonymous_enable=NO' /etc/vsftpd.conf
	# FTP user directories use chroot
	sudo sed -i '/^chroot_local_user/ c\chroot_local_user=YES' /etc/vsftpd.conf
	sudo service vsftpd restart
	echo "FTP has been configured"
fi
clear
echo "Does this machine need SSH? y or n: "
read sshYN
if [ "$sshYN" == "n" ]; then
	sudo apt-get purge openssh-server -y -qq
	sudo ufw deny ssh
	echo "Openssh has been purged and its ports have been blocked on UFW"
fi
if [ "$sshYN" == "y" ]; then
	sudo apt-get install openssh-server -y -qq
	sudo ufw allow ssh
	cp /etc/ssh/sshd_config ~/Desktop/backupfiles
	sudo sed -i '/IgnoreRhosts/c\IgnoreRhosts yes' /etc/ssh/sshd_config
	sudo sed -i '/HostbasedAuthentication/c\HostbasedAuthentication yes' /etc/ssh/sshd_config
	sudo sed -i '/Protocol/c\Protocol 2' /etc/ssh/sshd_config
	sudo sed -i '/LogLevel/c\LogLevel INFO' /etc/ssh/sshd_config
	sudo sed -i '/X11Forwarding/c\X11Forwarding no' /etc/ssh/sshd_config
	sudo sed -i '/MaxAuthTries/c\MaxAuthTries 4' /etc/ssh/sshd_config
	sudo sed -i '/PermitRootLogin/c\PermitRootLogin no' /etc/ssh/sshd_config
	sudo sed -i '/PermitEmptyPasswords/c\PermitEmptyPasswords no' /etc/ssh/sshd_config
	sudo sed -i '/PermitUserEnvironment/c\PermitUserEnvironment no' /etc/ssh/sshd_config
	sudo sed -i '/LoginGraceTime/c\LoginGraceTime 60' /etc/ssh/sshd_config
	echo "Password policies have been set"
	echo "Openssh has been installed."
fi
clear
echo "Does this machine need Telnet? y or n: "
read telnetYN
if [ "$telnetYN" == "n" ];then
	sudo ufw deny telnet 
	sudo ufw deny rtelnet 
	sudo ufw deny telnets
	sudo apt-get purge telnet -y -qq
	sudo apt-get purge telnetd -y -qq
	sudo apt-get purge inetutils-telnetd -y -qq
	sudo apt-get purge telnetd-ssl -y -qq
	echo "Telnet ports have been blocked on UFW and it has been purged."
fi
if [ "$telnetYN" == "y" ]; then
	sudo ufw allow telnet 
	sudo ufw allow rtelnet 
	sudo ufw allow telnets
	echo "All telnet ports have been allowed on the firewall."
fi
clear
echo "Does this machine need Mail? y or n: "
read mailYN
if [ "$mailYN" == "n" ]; then
	sudo ufw deny smtp
	sudo ufw deny pop2
	sudo ufw deny pop3
	sudo ufw deny imap2
	sudo ufw deny imaps
	sudo ufw deny pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been blocked on the firewall"
fi
if [ "$mailYN" == "y" ]; then
	sudo ufw allow smtp
        sudo ufw allow pop2
        sudo ufw allow pop3
        sudo ufw allow imap2
        sudo ufw allow imaps
        sudo ufw allow pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been allowed on the firewall"
fi
clear
echo "Does this machine need Printing? y or n: "
read printYN
if [ "$printYN" == "n" ];
then
	sudo ufw deny ipp 
	sudo ufw deny printer 
	sudo ufw deny cups
	echo "ipp, printer, and cups ports have been denied on the firewall."
elif [ "$printYN" == "y" ];
then
	sudo ufw allow ipp 
	sudo ufw allow printer 
	sudo ufw allow cups
	echo "ipp, printer, and cups ports have been allowed on the firewall."
fi
clear
echo "Does this machine need MySQL? y or n: "
read mysqlYN
if [ "$mysqlYN" == "n" ];
then
	sudo apt-get purge mysql -y -qq
	sudo apt-get purge mysql-client-core-5.5 -y -qq
	sudo apt-get purge mysql-client-core-5.6 -y -qq
	sudo apt-get purge mysql-common-5.5 -y -qq
	sudo apt-get purge mysql-common-5.6 -y -qq
	sudo apt-get purge mysql-server -y -qq
	sudo apt-get purge mysql-server-5.5 -y -qq
	sudo apt-get purge mysql-server-5.6 -y -qq
	sudo apt-get purge mysql-client-5.5 -y -qq
	sudo apt-get purge mysql-client-5.6 -y -qq
	sudo apt-get purge mysql-server-core-5.6 -y -qq
	sudo ufw deny ms-sql-s
	sudo ufw deny ms-sql-m
	sudo ufw deny mysql 
	sudo ufw deny mysql-proxy
	echo "MySQL has been removed. ms-sql-s, ms-sql-m, mysql, mysql-proxy have been denied on firewall."
elif [ "$mysqlYN" == "y" ];
then
	sudo ufw allow ms-sql-s 
	sudo ufw allow ms-sql-m 
	sudo ufw allow mysql 
	sudo ufw allow mysql-proxy
	echo "ms-sql-s, ms-sql-m, mysql, mysql-proxy have been allowed on firewall."
fi
clear
echo "Should this machine be a web server? y or n: "
read webYN
if [ "$webYN" == "n" ];
then
	sudo apt-get purge apache2
	sudo ufw deny http
	sudo ufw deny https
	echo "Apache2 has been removed. http and https have been denied on firewall."
elif [ "$mysqlYN" == "y" ];
then
	sudo apt-get install apache2
	sudo ufw allow http
	sudo ufw allow https
	echo "Apache2 has been installed. http and https have been allowed on firewall."
fi
echo "Does this machine need DNS? y or n: "
read dnsYN
if [ "$dnsYN" == "n" ];
then
	sudo apt-get purge bind9
	sudo ufw deny domain
	echo "DNS bind9 has been removed. Domain port has been denied on firewall."
elif [ "$dnsYN" == "y" ];
then
	sudo apt-get install bind9
	sudo ufw allow domain
	echo "DNS bind9 has been installed. domain port has been allowed on firewall."
fi

printf "deb http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\ndeb-src http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\n" | sudo tee -a /etc/apt/sources.list
echo "Install updates from configured."

clear
echo "Printing out all the malicious files:  "
find  /home -type f | while read file; do
    if [[  $file == *.midi || $file == *.mid || $file == *.mod || $file == *.mp3 || $file == *.mp2 || $file == *.mpa || $file == *.abs || $file == *.mpega || $file == *.au || $file == *.snd || $file == *.wav || $file == *.aiff || $file == *.aif || $file == *.sid || $file == *.flac || $file == *.ogg || $file == *.mpeg || $file == *.mpg || $file == *.mpe || $file == *.dl || $file == *.movie || $file == *.movi || $file == *.mv || $file == *.iff || $file == *.anim5 || $file == *.anim3 || $file == *.anim7 || $file == *.avi || $file == *.vfw || $file == *.avx || $file == *.fli || $file == *.flc || $file == *.mov || $file == *.qt || $file == *.spl || $file == *.swf || $file == *.dcr || $file == *.dir || $file == *.dxr || $file == *.rpm || $file == *.rm || $file == *.smi || $file == *.ra || $file == *.ram || $file == *.rv || $file == *.wmv || $file == *.asf || $file == *.asx || $file == *.wma || $file == *.wax || $file == *.wmv || $file == *.wmx || $file == *.3gp || $file == *.mov || $file == *.mp4 || $file == *.avi || $file == *.swf || $file == *.flv || $file == *.m4v || $file == *.tiff || $file == *.tif || $file == *.rs || $file == *.im1 || $file == *.gif || $file == *.jpeg || $file == *.jpg || $file == *.jpe || $file == *.png || $file == *.rgb || $file == *.xwd || $file == *.xpm || $file == *.ppm || $file == *.pbm || $file == *.pgm || $file == *.pcx || $file == *.ico || $file == *.svg || $file == *.svgz  || $file == *.txt ]]; then
        echo $file;
    fi
done
echo "Continue? (don't put anything other than y): "
read continuecheck
if [ "$continuecheck" == "y"]; then
	clear
fi
echo "Does this machine allow weird files? y or n: "
read mediaFilesYN
if [ "$mediaFilesYN" == "n" ];
then
find / -name '*.midi' -type f -delete
find / -name '*.mid' -type f -delete
find / -name '*.mod' -type f -delete
find / -name '*.mp3' -type f -delete
find / -name '*.mp2' -type f -delete
find / -name "*.mpa" -type f -delete
find / -name "*.abs" -type f -delete
find / -name "*.mpega" -type f -delete
find / -name "*.au" -type f -delete
find / -name "*.snd" -type f -delete
find / -name "*.wav" -type f -delete
find / -name "*.aiff" -type f -delete
find / -name "*.aif" -type f -delete
find / -name "*.sid" -type f -delete
find / -name "*.flac" -type f -delete
find / -name "*.ogg" -type f -delete
find / -name "*.mpeg" -delete
find / -name "*.mpg" -type f -delete
find / -name "*.mpe" -type f -delete
find / -name "*.dl" -type f -delete
find / -name "*.movie" -type f -delete
find / -name "*.movi" -type f -delete
find / -name "*.mv" -type f -delete
find / -name "*.iff" -type f -delete
find / -name "*.anim5" -type f -delete
find / -name "*.anim3" -type f -delete
find / -name "*.anim7" -type f -delete
find / -name "*.avi" -type f -delete
find / -name "*.vfw" -type f -delete
find / -name "*.avx" -type f -delete
find / -name "*.fli" -type f -delete
find / -name "*.flc" -type f -delete
find / -name "*.mov" -type f -delete
find / -name "*.qt" -type f -delete
find / -name "*.spl" -type f -delete
find / -name "*.swf" -type f -delete
find / -name "*.dcr" -type f -delete
find / -name "*.dir" -type f -delete
find / -name "*.dxr" -type f -delete
find / -name "*.rpm" -type f -delete
find / -name "*.rm" -type f -delete
find / -name "*.smi" -type f -delete
find / -name "*.ra" -type f -delete
find / -name "*.ram" -type f -delete
find / -name "*.rv" -type f -delete
find / -name "*.wmv" -type f -delete
find / -name "*.asf" -type f -delete
find / -name "*.asx" -type f -delete
find / -name "*.wma" -type f -delete
find / -name "*.wax" -type f -delete
find / -name "*.wmv" -type f -delete
find / -name "*.wmx" -type f -delete
find / -name "*.3gp" -type f -delete
find / -name "*.mov" -type f -delete
find / -name "*.mp4" -type f -delete
find / -name "*.avi" -type f -delete
find / -name "*.swf" -type f -delete
find / -name "*.flv" -type f -delete
find / -name "*.m4v" -type f -delete
find / -name "*.tiff" -type f -delete
find / -name "*.tif" -type f -delete
find / -name "*.rs" -type f -delete
find / -name "*.im1" -type f -delete
find / -name "*.gif" -type f -delete
find / -name "*.jpeg" -type f -delete
find / -name "*.jpg" -type f -delete
find / -name "*.jpe" -type f -delete
find / -name "*.png" -type f -delete
find / -name "*.rgb" -type f -delete
find / -name "*.xwd" -type f -delete
find / -name "*.xpm" -type f -delete
find / -name "*.ppm" -type f -delete
find / -name "*.pbm" -type f -delete
find / -name "*.pgm" -type f -delete
find / -name "*.pcx" -type f -delete
find / -name "*.ico" -type f -delete
find / -name "*.svg" -type f -delete
find / -name "*.svgz" -type f -delete
echo "Malicious files have been removed."
fi
clear
echo "Does IPv6 need to be disabled? y or n: "
read ipv6YN
if [ "$ipv6YN" == "y" ];
then
	printf "net.ipv6.conf.all.disable_ipv6=1\nnet.ipv6.conf.default.disable_ipv6=1\nnet.ipv6.conf.lo.disable_ipv6=1" | sudo tee -a /etc/sysctl.conf
	sudo sysctl -p
	echo "IPv6 has been disabled"
else
	printf "net.ipv6.conf.all.disable_ipv6=0\nnet.ipv6.conf.default.disable_ipv6=0\nnet.ipv6.conf.lo.disable_ipv6=0" | sudo tee -a /etc/sysctl.conf
	sudo sysctl -p
	echo "IPv6 has not been disabled"
fi
clear
echo "Do you want to disable IP forwarding? y or n: "
read ipforwardYN
if [ "$ipforwardYN" == "y" ];
then
	echo 0 | sudo tee /proc/sys/net/ipv4/ip_forward
	echo "IP forwarding has been disabled"
fi
clear
echo "Do you want to disable ASLR? y or n: "
read aslrYN
if [ "$aslrYN" == "y" ];
then
	echo 2 | sudo tee /proc/sys/kernel/randomize_va_space
	echo "ASLR has been disabled."
fi
clear
echo "Do you want to prevent IP spoofing? y or n: "
read ipspoofYN
if [ "$ipspoofYN" == "y" ];
then
	echo "nospoof on" | sudo tee -a /etc/host.conf
fi
clear

sudo apt-get purge netcat -y -qq
clear
echo "Netcat and all other instances have been removed."

sudo apt-get purge john -y -qq
clear
echo "John the Ripper has been removed."

sudo apt-get remove nmap
clear
echo "Zenmap and Nmap removed."

sudo apt-get remove wireshark
clear
echo "Wireshark removed."

sudo apt-get purge hydra -y -qq
clear
echo "Hydra has been removed."

sudo apt-get purge aircrack-ng -y -qq
clear
echo "Aircrack-NG has been removed."

sudo apt-get purge fcrackzip -y -qq
clear
echo "FCrackZIP has been removed."

sudo apt-get purge lcrack -y -qq
clear
echo "LCrack has been removed."

sudo apt-get purge ophcrack -y -qq
clear
echo "OphCrack has been removed."

sudo apt-get purge pdfcrack -y -qq
clear
echo "PDFCrack has been removed."

sudo apt-get purge pyrit -y -qq
clear
echo "Pyrit has been removed."

sudo apt-get purge rarcrack -y -qq
clear
echo "RARCrack has been removed."

sudo apt-get purge sipcrack -y -qq
clear
echo "SipCrack has been removed."

sudo apt-get purge irpas -y -qq
clear
echo "IRPAS has been removed."

sudo apt-get purge logkeys -y -qq
clear 
echo "LogKeys has been removed."

sudo apt-get purge zeitgeist -y -qq
clear
echo "Zeitgeist has been removed."

sudo apt-get purge nfs-kernel-server -y -qq
clear
echo "NFS has been removed."

sudo apt-get purge nginx -y -qq
clear
echo "NGINX has been removed."

sudo apt-get purge inetd -y -qq
clear
echo "Inetd (super-server) and all inet utilities have been removed."

sudo apt-get purge vnc4server -y -qq
clear
echo "VNC has been removed."

sudo apt-get purge snmp -y -qq
clear
echo "SNMP has been removed."

sudo apt-get purge kismet
clear
echo "kismet has been removed."

sudo apt-get purge cryptcat
clear
echo "cryptcat has been removed."

sudo apt autoremove
clear
echo "All unnecessary packages have been removed."

printf "deb http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\ndeb-src http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\n" | sudo tee -a /etc/apt/sources.list
sudo apt-get install unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
clear
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/10periodic
echo "Updates tab configured."
clear

for dir in `cat /etc/passwd | egrep -v '(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin") { print $6 }'`; do
  for file in $dir/.rhosts; do
    if [ ! -h "$file" -a -f "$file" ]; then
        read -p "Delete .rhosts file in $dir? y or n: " ans
        if [ "$ans" == "y" ]; then
                echo "Deleted .rhosts file in $dir"
                sudo rm $file
        fi
    fi 
  done 
done

read -p "Update? y or n: " ans
if [ "$ans" == "y" ]; then
	sudo apt-get dist-upgrade
	echo "Kernel update"
	echo "Installing updates"
	sudo apt update
	sudo apt upgrade
	clear
fi
clear
echo "Reboot computer now"



