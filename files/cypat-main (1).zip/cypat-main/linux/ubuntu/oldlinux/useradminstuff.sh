#!/bin/bash

mkdir -p ~/Desktop/backupfiles
chmod 777 ~/Desktop/backupfiles

cp /etc/group ~/Desktop/backupfiles
cp /etc/passwd ~/Desktop/backupfiles

desired_admins=()
desired_users=()
all_users=()
adminoruser=true
input="readme.txt"
goduser=""
read -p "Have you changed the readme file? y or n: " ans
if [ "$ans" == "y" ]; then
	while IFS= read -r line
	do
	  if [ "$line" == "Authorized Administrators:" ]; then
			adminoruser=true
	  else
			if [ "$line" == "Authorized Users:" ]; then
					adminoruser=false 
			fi
	  fi
	  if [ "$adminoruser" = true ]; then
			if [ "$line" != "Authorized Administrators:" ]; then
					if [[ "$line" != *"password:"* ]]; then
							output=$( echo "$line" |cut -d' ' -f 1 )
							if [[ "$line" == *"("* ]]; then
								goduser="$output"
							fi
							desired_admins+=("$output")
							all_users+=("$output")
					fi
			fi
	  else
			if [ "$line" != "Authorized Users:" ]; then
					desired_users+=("$line")
					all_users+=("$line")
			fi
	  fi
	done < "$input"
	sudo getent passwd | while IFS=: read -r name password uid gid gecos home shell;
	do
	if [ -d "$home" ] && [ "$(stat -c %u "$home")" = "$uid" ]; then
	if [ ! -z "$shell" ] && [ "$shell" != "/bin/false" ] && [ "$shell" !=  "/usr/sbin/nologin" ]; then
			#delete users who aren't supposed to be there
			if [ "$name" != "root" ]; then
			if [[ " ${all_users[*]} " != *" $name "* ]]; then
				echo "Deleting user $name"
				sudo userdel "$name"
			fi
			if [ "$name" != "$goduser" ]; then
				echo "$name:NJr643vZ9TL" | sudo chpasswd
				echo "Changed "$name" password"
			fi
			#admin users who shouldn't be admins but are
			if getent group sudo | grep -q "\b${name}\b"; then
					if [[ " ${desired_admins[*]} " != *" $name "* ]]; then
							echo "Removing $name from sudoer group"
							sudo deluser "$name" sudo
					fi
			fi
			#users who should be admins but are not
			if [[ " ${desired_admins[*]} " == *" $name "* ]]; then
					if getent group sudo | grep -q "\b${name}\b"; then
							continue;
					else
							echo "Giving $name sudo permissions"
							sudo usermod -aG sudo "$name"
					fi
			fi
			fi
	fi
	fi
	done
	read -p "Type the name of the user you want to add (type no if you don't want to add any users): " ans
	if [ "$ans" != "no" ]; then
			echo "Adding user $ans"
			sudo useradd "$ans"
			sudo usermod -p "NJr643vZ9TL" "$ans"
			sudo usermod -U "$ans"
			read -p "Should the user be an admin? y or n: " adminans
			if [ "$adminans" == "y" ]; then
				echo "Making $ans an admin"
				sudo usermod -aG sudo "$ans"
			fi
	fi
	sudo getent passwd | while IFS=: read -r name password uid gid gecos home shell;
	do
	if [ -d "$home" ] && [ "$(stat -c %u "$home")" = "$uid" ]; then
	if [ ! -z "$shell" ] && [ "$shell" != "/bin/false" ] && [ "$shell" !=  "/usr/sbin/nologin" ]; then
	if [ `sudo awk -F ':' '/^'$name':/ {print $2}' /etc/shadow` ] ; then 
	   continue; 
	else 
	   echo "Adding password for $name";
	   echo $name:$name"NJr643vZ9TL" | sudo chpasswd;
	fi
	fi
	fi
	done
fi
