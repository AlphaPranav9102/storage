# TO DO (Bash Script - Ubuntu)

### Account Management
- ~~Delete users who aren't supposed to be there~~
- ~~Add users who are supposed to be there~~
- ~~Demote system admins who are supposed to be users~~
- ~~Promote system users who are supposed to be admins~~
- ~~Add passwords to users who don't have passwords~~
- ~~Make stronger passwords~~

### Security Policies
- ~~Permit Root Login~~
- ~~Disable Guest Account~~
- Cron Job
- ~~CTRL ALT DELETE disable~~
- ~~Remove unused packages~~
- Disable rhosts
- Disable rlogins
- ~~Disable IP Forwarding~~
- ~~Disable ASLR~~

#### Services
- ~~UFW~~
- ~~Samba~~
- ~~FTP~~
- ~~SSH~~
- ~~Telnet~~
- ~~Mail services~~
- ~~Printing Services~~
- ~~MySQL~~
- ~~Web Server~~
- ~~DNS~~
- ~~Media Files~~
- ~~IPv6~~

#### Password policies
- ~~PASS_MAX_DAYS~~
- ~~PASS_MIN_DAYS~~
- ~~PASS_WARN_DAYS~~
- ~~Lockout Retry~~
- ~~Min Len~~
- ~~Password History~~
- ~~Lockout~~
- Check if MIN_LEN can be edited in login.defs

#### Malware (remove these)
- ~~Medusa~~
- ~~Hydra~~
- Truecrack
- ~~Ophcrack~~
- ~~Kismet~~
- ~~John~~
- Nikto
- ~~cryptcat~~
- ~~nc~~
- clamav
- ~~nmap and zenmap~~
- Remmina
- Transmission
- ~~Aircrack-NG~~
- ~~FCrackZip~~
- ~~LCrack~~
- ~~PDFCrack~~
- ~~Pyrit~~
- ~~RARCrack~~
- ~~SipCrack~~
- ~~IRPAS~~
- ~~LogKeys~~
- ~~Zeitgeist~~
- ~~NFS~~
- ~~NGINX~~
- ~~Inetd~~
- ~~VNC~~
- ~~Wireshark~~
- ~~SNMP~~

### Updates
- Enabling updates (3 checkboxes)
- Automatically checking for updates: Daily
- When there are security updates: Donwload and install automatically
- When there are updates: Display Daily
- Notify me of a new Ubuntu version

## Misc
- log
- ~~create backup of critical files~~
