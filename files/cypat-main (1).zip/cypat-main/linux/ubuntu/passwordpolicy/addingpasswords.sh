#!/bin/bash
sudo getent passwd | while IFS=: read -r name password uid gid gecos home shell;
do
if [ -d "$home" ] && [ "$(stat -c %u "$home")" = "$uid" ]; then
if [ ! -z "$shell" ] && [ "$shell" != "/bin/false" ] && [ "$shell" !=  "/usr/sbin/nologin" ]; then
if [ `sudo awk -F ':' '/^'$name':/ {print $2}' /etc/shadow` ] ; then 
   continue; 
else 
   echo "Adding password for $name";
   echo $name:$name"NJr643vZ9TL" | sudo chpasswd;
fi
fi
fi
done
#boi u thought