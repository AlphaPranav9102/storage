#!/bin/bash
sudo apt-get install libpam-pwquality
sudo sed -i 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS 30/g' /etc/login.defs
sudo sed -i 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS 7/g' /etc/login.defs
sudo sed -i 's/^PASS_WARN_AGE.*/PASS_WARN_AGE 14/g' /etc/login.defs
sudo sed -i '/difok/c\difok = 1' /etc/security/pwquality.conf
sudo sed -i '/minlen/c\minlen = 8' /etc/security/pwquality.conf
sudo sed -i '/minclass/c\minclass = 3' /etc/security/pwquality.conf
sudo sed -i '/maxrepeat/c\maxrepeat = 2' /etc/security/pwquality.conf
sudo sed -i '/dcredit/c\dcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ucredit/c\ucredit = 1' /etc/security/pwquality.conf
sudo sed -i '/lcredit/c\lcredit = 1' /etc/security/pwquality.conf
sudo sed -i '/ocredit/c\ocredit = 1' /etc/security/pwquality.conf
sudo sed -i '/IgnoreRhosts/c\IgnoreRhosts yes' /etc/ssh/sshd_config
sudo sed -i '/HostbasedAuthentication/c\HostbasedAuthentication yes' /etc/ssh/sshd_config
sudo sed -i '/Protocol/c\Protocol 2' /etc/ssh/sshd_config
sudo sed -i '/LogLevel/c\LogLevel INFO' /etc/ssh/sshd_config
sudo sed -i '/X11Forwarding/c\X11Forwarding no' /etc/ssh/sshd_config
sudo sed -i '/MaxAuthTries/c\MaxAuthTries 4' /etc/ssh/sshd_config
sudo sed -i '/PermitRootLogin/c\PermitRootLogin no' /etc/ssh/sshd_config
sudo sed -i '/PermitEmptyPasswords/c\PermitEmptyPasswords no' /etc/ssh/sshd_config
sudo sed -i '/PermitUserEnvironment/c\PermitUserEnvironment no' /etc/ssh/sshd_config
sudo sed -i '/LoginGraceTime/c\LoginGraceTime 60' /etc/ssh/sshd_config
echo "Password policies have been set"
