#!/bin/bash

echo "Does this machine need UFW? y or n: "
read ufwYN
if [ "$ufwYN" == "y" ]; then
	sudo ufw enable
	sudo ufw deny 1337
fi
if [ "$ufwYN" == "n" ]; then
	sudo ufw disable
fi
clear

echo "Does IPv6 need to be disabled? y or n: "
read ipv6YN
if [ "$ipv6YN" == "y" ];
then
	printf "net.ipv6.conf.all.disable_ipv6=1\nnet.ipv6.conf.default.disable_ipv6=1\nnet.ipv6.conf.lo.disable_ipv6=1" | sudo tee -a /etc/sysctl.conf
	sudo sysctl -p
	echo "IPv6 has been disabled"
else
	printf "net.ipv6.conf.all.disable_ipv6=0\nnet.ipv6.conf.default.disable_ipv6=0\nnet.ipv6.conf.lo.disable_ipv6=0" | sudo tee -a /etc/sysctl.conf
	sudo sysctl -p
	echo "IPv6 has not been disabled"
fi
clear

echo "Do you want to disable IP forwarding? y or n: "
read ipforwardYN
if [ "$ipforwardYN" == "y" ];
then
	echo 0 | sudo tee /proc/sys/net/ipv4/ip_forward
	echo "IP forwarding has been disabled"
fi
clear

echo "Do you want to disable ASLR? y or n: "
read aslrYN
if [ "$aslrYN" == "y" ];
then
	echo 2 | sudo tee /proc/sys/kernel/randomize_va_space
	echo "ASLR has been disabled."
fi
clear

echo "Do you want to prevent IP spoofing? y or n: "
read ipspoofYN
if [ "$ipspoofYN" == "y" ];
then
	echo "nospoof on" | sudo tee -a /etc/host.conf
fi
clear