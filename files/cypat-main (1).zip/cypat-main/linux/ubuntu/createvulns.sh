sudo useradd ballen
echo "ballen:ir!%West" | sudo chpasswd
sudo usermod -U ballen
sudo useradd iwest
echo "iwest:JiTTerS" | sudo chpasswd
sudo usermod -U iwest
sudo useradd pspivot
echo "pspivot:thawne25" | sudo chpasswd
sudo usermod -U pspivot
sudo useradd grodd
echo "grodd:ZoLomOn" | sudo chpasswd
sudo usermod -U grodd
sudo useradd jwells
echo "jwells:quick" | sudo chpasswd
sudo usermod -U jwells
sudo useradd cramon
sudo useradd hrathaway
sudo useradd jwest
sudo useradd wwest
sudo useradd csnow
sudo useradd lsnart
sudo useradd hallen
sudo useradd ethawne
sudo useradd jgarrick
sudo useradd savitar
sudo useradd nallen
sudo useradd mstein
sudo useradd mrory
sudo useradd hwells
sudo useradd jalbert
sudo usermod -aG sudo ballen
sudo usermod -aG sudo iwest
sudo usermod -aG sudo grodd
sudo usermod -aG sudo jwells
sudo usermod -aG sudo savitar #not supposed to be an admin
sudo useradd tswift #not supposed to be a user
sudo usermod -aG sudo tswift #not supposed to be an admin

#pspivot needs to be added to admin group