#!/bin/bash

mkdir -p ~/Desktop/backupfiles
chmod 777 ~/Desktop/backupfiles

cp /etc/group ~/Desktop/backupfiles
cp /etc/passwd ~/Desktop/backupfiles

#permissions to files
sudo chmod +x userstuff.sh
sudo chmod +x pamconfig.sh
sudo chmod +x lightdm.sh
sudo chmod +x secureaccounts.sh
sudo chmod +x services.sh
sudo chmod +x packages.sh
sudo chmod +x updateconfig.sh
sudo chmod +x update.sh
sudo chmod +x maliciousfiles.sh
sudo chmod +x rhosts.sh
sudo chmod +x secure.sh
sudo chmod +x network.sh

read -p "Run the entire script start to finish?: y or n: " scriptans
case "$scriptans" in
    y) echo "Running script in order..." 
       ./userstuff.sh #
       clear
       ./network.sh #
       clear
       ./pamconfig.sh #
       clear
       ./lightdm.sh #
       clear
       ./secureaccounts.sh #
       clear
       ./secure.sh #
       clear
       ./services.sh #
       clear
       ./packages.sh #
       clear
       ./maliciousfiles.sh #
       clear
       ./rhosts.sh #
       clear
       ./updateconfig.sh #
       clear
       ./update.sh #
       clear
    ;;
    n) echo -e "Welcome to the Cyberpatriot Team 2 Collective Linux Script. Please follow the instructions below and input only what's given.\n"
    echo -e "1. User admin stuff\n2. Secure Accounts\n3. Disable Guest User\n4. Password Requirements\n5. Find Malicious Files\n6. Removing *sus* Packages\n7. Configure Services\n8. Delete rhost Files\n9. Secure Shadow and Passwd Files\n10. Update\nquit: to end the script\n"
    read nextmove
    while [ "$nextmove" != "quit" ]; do
        case "$nextmove" in
            1) echo "Executing User Admin stuff..."
            ./userstuff.sh
            ;;
            2) echo "Securing accounts..."
            ./secureaccounts.sh
            ;;
            3) echo "Disabling guest user..."
            ./lightdm.sh
            ;;
            4) echo "Establishing password requirements..."
            ./pamconfig.sh
            ;;
            5) echo "Finding malicious files..."
            ./maliciousfiles.sh
            ;;
            6) echo "Removing *sus* packages..."
            ./packages.sh
            ;;
            7) echo "Configuring services..."
            ./services.sh
            ;;
            8) echo "Deleting rhost files..."
            ./rhosts.sh
            ;;
            9) echo "Securing passwd and shadow files..."
            ./secure.sh
            ;;
            10) echo "Securing network..."
            ./network.sh
            ;;
            11) echo "Retrieving and installing updates..."
            ./updateconfig.sh
            ./updates.sh
            ;;
            *) break;; #default case
        esac
        clear 
        echo -e "1. User admin stuff\n2. Secure Accounts\n3. Disable Guest User\n4. Password Requirements\n5. Find Malicious Files\n6. Removing *sus* Packages\n7. Configure Services\n8. Delete rhost Files\n9. Secure Shadow and Passwd Files\n10. Secure Network\n11. Update\nquit: to end the script\n"
        read nextmove
    done
    ;; 
esac
echo "Script done. Goodbye."