#!/bin/bash

read -p "Update? y or n: " ans
if [ "$ans" == "y" ]; then
	sudo apt-get dist-upgrade
	echo "Kernel update"
	echo "Installing updates"
	sudo apt update
	sudo apt upgrade
	clear
fi
clear
echo "Reboot computer now"