#!/bin/bash

# Shadow File - read, write for sudo users; read for group
read -p "Secure Shadow File? y or n: " ans
if [ "$ans" == "y" ]; then
    sudo chmod -R 640 /etc/shadow
    echo "Shadow file secured"
fi



# Passwd File - read, write for sudo users; read for group and all other users
read -p "Secure Passwd File? y or n: " ans
if [ "$ans" == "y" ]; then
    sudo chmod -R 644 /etc/passwd
    echo "Passwd file secured"
fi

