#!/bin/bash

sudo apt-get install lightdm
dpkg-reconfigure lightdm
clear
cp /etc/lightdm/lightdm.conf.d ~/Desktop/backupfiles
read -p "Disable guest account? y or n: " ans
echo "Creating lightdm.conf.d"
sudo mkdir /etc/lightdm/lightdm.conf.d
case "$ans" in
        y) sudo sh -c 'printf "[Seat:*]\nallow-guest=false\n" >/etc/lightdm/lightdm.conf.d/50-no-guest.conf'
           echo "Guest account disabled (will go into affect on system reboot)"
	;;
        n) echo "Guest account will not be disabled"
esac

read -p "Restart lightdm? y or n: "
case "$ans" in
    y) echo "Restarting lightdm..."
    sudo restart lightdm
    ;;
    n) echo "Lightdm will not be restarted"
esac