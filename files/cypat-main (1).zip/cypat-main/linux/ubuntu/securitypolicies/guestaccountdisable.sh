#!/bin/bash
read -p "Disable guest account? y or n: " ans
echo "Creating lightdm.conf.d"
sudo mkdir /etc/lightdm/lightdm.conf.d
case "$ans" in
        y) sudo sh -c 'printf "[Seat:*]\nallow-guest=false\n" >/etc/lightdm/lightdm.conf.d/50-no-guest.conf'
           echo "Guest account disabled (will go into affect on system reboot)"
	;;
        n) echo "Guest account will not be disabled"
esac

#sudo restart lightdm to disable guest account
