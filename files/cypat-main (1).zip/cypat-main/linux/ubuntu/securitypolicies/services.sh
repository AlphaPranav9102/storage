#!/bin/bash
echo "Does this machine need UFW? y or n: "
read ufwYN
if [ "$ufwYN" == "y" ]; then
	sudo ufw enable
	sudo ufw deny 1337
fi
if [ "$ufwYN" == "n" ]; then
	sudo ufw disable
fi
clear
echo "Does this machine need Samba? y or n: "
read sambaYN
if [ "$sambaYN" == "n" ]; then
	sudo ufw deny netbios-ns
	sudo ufw deny netbios-dgm
	sudo ufw deny netbios-ssn
	sudo ufw deny microsoft-ds
	sudo apt-get purge samba -y -qq
	sudo apt-get purge samba-common -y  -qq
	sudo apt-get purge samba-common-bin -y -qq
	sudo apt-get purge samba4 -y -qq
	echo "netbios-ns, netbios-dgm, netbios-ssn, and microsoft-ds ports have been denied and Samba has been uninstalled.";
fi
if [ "$sambaYN" == "y" ]; then
	sudo ufw allow netbios-ns
	sudo ufw allow netbios-dgm
	sudo ufw allow netbios-ssn
	sudo ufw allow microsoft-ds
	sudo apt-get install samba -y -qq
	sudo apt-get install system-config-samba -y -qq
	echo "Samba has been configured"
fi
clear
echo "Does this machine need FTP? y or n: "
read ftpYN
if [ "$ftpYN" == "n" ]; then
	sudo apt-get purge vsftpd -y -qq
	sudo apt-get remove pure-ftpd
	sudo ufw deny ftp
	sudo ufw deny sftp
	sudo ufw deny saft 
	sudo ufw deny ftps-data 
	sudo ufw deny ftps
	echo "vstfpd has been purged and ftp ports have been blocked on UFW"
fi
if [ "$ftpYN" == "y" ]; then
	sudo ufw allow ftp 
	sudo ufw allow sftp 
	sudo ufw allow saft 
	sudo ufw allow ftps-data 
	sudo ufw allow ftps
	sudo service vsftpd restart
	# Disable anonymous uploads
	sudo sed -i '/^anon_upload_enable/ c\anon_upload_enable no' /etc/vsftpd.conf
	sudo sed -i '/^anonymous_enable/ c\anonymous_enable=NO' /etc/vsftpd.conf
	# FTP user directories use chroot
	sudo sed -i '/^chroot_local_user/ c\chroot_local_user=YES' /etc/vsftpd.conf
	sudo service vsftpd restart
	echo "FTP has been configured"
fi
clear
echo "Does this machine need SSH? y or n: "
read sshYN
if [ "$sshYN" == "n" ]; then
	sudo apt-get purge openssh-server -y -qq
	sudo ufw deny ssh
	echo "Openssh has been purged and its ports have been blocked on UFW"
fi
if [ "$sshYN" == "y" ]; then
	sudo apt-get install openssh-server -y -qq
	sudo ufw allow ssh
	echo "Openssh has been installed."
fi
clear
echo "Does this machine need Telnet? y or n: "
read telnetYN
if [ "$telnetYN" == "n" ];then
	sudo ufw deny telnet 
	sudo ufw deny rtelnet 
	sudo ufw deny telnets
	sudo apt-get purge telnet -y -qq
	sudo apt-get purge telnetd -y -qq
	sudo apt-get purge inetutils-telnetd -y -qq
	sudo apt-get purge telnetd-ssl -y -qq
	echo "Telnet ports have been blocked on UFW and it has been purged."
fi
if [ "$telnetYN" == "y" ]; then
	sudo ufw allow telnet 
	sudo ufw allow rtelnet 
	sudo ufw allow telnets
	echo "All telnet ports have been allowed on the firewall."
fi
clear
echo "Does this machine need Mail? y or n: "
read mailYN
if [ "$mailYN" == "n" ]; then
	sudo ufw deny smtp
	sudo ufw deny pop2
	sudo ufw deny pop3
	sudo ufw deny imap2
	sudo ufw deny imaps
	sudo ufw deny pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been blocked on the firewall"
fi
if [ "$mailYN" == "y" ]; then
	sudo ufw allow smtp
        sudo ufw allow pop2
        sudo ufw allow pop3
        sudo ufw allow imap2
        sudo ufw allow imaps
        sudo ufw allow pop3s
	echo "SMTP, POP2, POP3, IMAP2, IMAPS, and POP3 have been allowed on the firewall"
fi
clear
echo "Does this machine need Printing? y or n: "
read printYN
if [ "$printYN" == "n" ];
then
	ufw deny ipp 
	ufw deny printer 
	ufw deny cups
	echo "ipp, printer, and cups ports have been denied on the firewall."
elif [ "$printYN" == "y" ];
then
	ufw allow ipp 
	ufw allow printer 
	ufw allow cups
	echo "ipp, printer, and cups ports have been allowed on the firewall."
fi
clear
echo "Should IPv6 be disabled? y or n: "
read IPv6YN
if ["$IPv6YN" == "y" ]; then
	echo "net.ipv6.conf.all.disable_ipv6=1" | sudo tee -a /etc/sysctl.conf
        echo "net.ipv6.conf.default.disable_ipv6=1" | sudo tee -a /etc/sysctl.conf
        echo "net.ipv6.conf.lo.disable_ipv6=1" | sudo tee -a /etc/sysctl.conf
        sudo sysctl -p
	echo "IPv6 has been disabled."
fi
echo "Does this machine allow media files? y or n: "
read mediaFilesYN
find / -name '*.midi' -type f -delete
find / -name '*.mid' -type f -delete
find / -name '*.mod' -type f -delete
find / -name '*.mp3' -type f -delete
find / -name '*.mp2' -type f -delete
find / -name "*.mpa" -type f -delete
find / -name "*.abs" -type f -delete
find / -name "*.mpega" -type f -delete
find / -name "*.au" -type f -delete
find / -name "*.snd" -type f -delete
find / -name "*.wav" -type f -delete
find / -name "*.aiff" -type f -delete
find / -name "*.aif" -type f -delete
find / -name "*.sid" -type f -delete
find / -name "*.flac" -type f -delete
find / -name "*.ogg" -type f -delete
find / -name "*.mpeg" -delete
find / -name "*.mpg" -type f -delete
find / -name "*.mpe" -type f -delete
find / -name "*.dl" -type f -delete
find / -name "*.movie" -type f -delete
find / -name "*.movi" -type f -delete
find / -name "*.mv" -type f -delete
find / -name "*.iff" -type f -delete
find / -name "*.anim5" -type f -delete
find / -name "*.anim3" -type f -delete
find / -name "*.anim7" -type f -delete
find / -name "*.avi" -type f -delete
find / -name "*.vfw" -type f -delete
find / -name "*.avx" -type f -delete
find / -name "*.fli" -type f -delete
find / -name "*.flc" -type f -delete
find / -name "*.mov" -type f -delete
find / -name "*.qt" -type f -delete
find / -name "*.spl" -type f -delete
find / -name "*.swf" -type f -delete
find / -name "*.dcr" -type f -delete
find / -name "*.dir" -type f -delete
find / -name "*.dxr" -type f -delete
find / -name "*.rpm" -type f -delete
find / -name "*.rm" -type f -delete
find / -name "*.smi" -type f -delete
find / -name "*.ra" -type f -delete
find / -name "*.ram" -type f -delete
find / -name "*.rv" -type f -delete
find / -name "*.wmv" -type f -delete
find / -name "*.asf" -type f -delete
find / -name "*.asx" -type f -delete
find / -name "*.wma" -type f -delete
find / -name "*.wax" -type f -delete
find / -name "*.wmv" -type f -delete
find / -name "*.wmx" -type f -delete
find / -name "*.3gp" -type f -delete
find / -name "*.mov" -type f -delete
find / -name "*.mp4" -type f -delete
find / -name "*.avi" -type f -delete
find / -name "*.swf" -type f -delete
find / -name "*.flv" -type f -delete
find / -name "*.m4v" -type f -delete
find / -name "*.tiff" -type f -delete
find / -name "*.tif" -type f -delete
find / -name "*.rs" -type f -delete
find / -name "*.im1" -type f -delete
find / -name "*.gif" -type f -delete
find / -name "*.jpeg" -type f -delete
find / -name "*.jpg" -type f -delete
find / -name "*.jpe" -type f -delete
find / -name "*.png" -type f -delete
find / -name "*.rgb" -type f -delete
find / -name "*.xwd" -type f -delete
find / -name "*.xpm" -type f -delete
find / -name "*.ppm" -type f -delete
find / -name "*.pbm" -type f -delete
find / -name "*.pgm" -type f -delete
find / -name "*.pcx" -type f -delete
find / -name "*.ico" -type f -delete
find / -name "*.svg" -type f -delete
find / -name "*.svgz" -type f -delete

echo "Media files have been removed."
clear

sudo apt-get purge netcat -y -qq
clear
echo "Netcat and all other instances have been removed."

sudo apt-get purge john -y -qq
clear
echo "John the Ripper has been removed."

sudo apt-get remove nmap
clear
echo "Zenmap and Nmap removed."

sudo apt-get remove wireshark
clear
echo "Wireshark removed.

sudo apt-get purge hydra -y -qq
clear
echo "Hydra has been removed."

sudo apt-get purge aircrack-ng -y -qq
clear
echo "Aircrack-NG has been removed."

sudo apt-get purge fcrackzip -y -qq
clear
echo "FCrackZIP has been removed."

sudo apt-get purge lcrack -y -qq
clear
echo "LCrack has been removed."

sudo apt-get purge ophcrack -y -qq
clear
echo "OphCrack has been removed."

sudo apt-get purge pdfcrack -y -qq
clear
echo "PDFCrack has been removed."

sudo apt-get purge pyrit -y -qq
clear
echo "Pyrit has been removed."

sudo apt-get purge rarcrack -y -qq
clear
echo "RARCrack has been removed."

sudo apt-get purge sipcrack -y -qq
clear
echo "SipCrack has been removed."

sudo apt-get purge irpas -y -qq
clear
echo "IRPAS has been removed."

sudo apt-get purge logkeys -y -qq
clear 
echo "LogKeys has been removed."

sudo apt-get purge zeitgeist -y -qq
clear
echo "Zeitgeist has been removed."

sudo apt-get purge nfs-kernel-server -y -qq
clear
echo "NFS has been removed."

sudo apt-get purge nginx -y -qq
clear
echo "NGINX has been removed."

sudo apt-get purge inetd -y -qq
clear
echo "Inetd (super-server) and all inet utilities have been removed."

sudo apt-get purge vnc4server -y -qq
clear
echo "VNC has been removed."

sudo apt-get purge snmp -y -qq
clear
echo "SNMP has been removed."

sudo apt-get purge medusa -y -qq
clear
echo "medusa has been removed."

##sudo apt-get purge transmission
##clear
##echo "transmission has been removed."

sudo apt autoremove
clear
echo "All unnecessary packages have been removed."

sudo apt-get install unattended-upgrades
if grep -q "Update-Package-Lists" /etc/apt/apt.conf.d/20auto-upgrades; then
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/20auto-upgrades
else
echo 'APT::Periodic::Update-Package-Lists "1";' | sudo tee -a /etc/apt/apt.conf.d/20auto-upgrades
fi
if grep -q "Unattended-Upgrade" /etc/apt/apt.conf.d/20auto-upgrades; then
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/20auto-upgrades
else
echo 'APT::Periodic::Unattended-Upgrade "1";' | sudo tee -a /etc/apt/apt.conf.d/20auto-upgrades
fi
sudo sed -i '/"${distro_id}:${distro_codename}-security";/c\"${distro_id}:${distro_codename}-security";' /etc/apt/apt.conf.d/50unattended-upgrades
sudo sed -i '/"${distro_id}:${distro_codename}-updates";/c\"${distro_id}:${distro_codename}-updates";' /etc/apt/apt.conf.d/50unattended-upgrades
sudo sed -i '/"${distro_id}:${distro_codename}-proposed";/c\"${distro_id}:${distro_codename}-proposed";' /etc/apt/apt.conf.d/50unattended-upgrades
sudo sed -i '/"${distro_id}:${distro_codename}-backports";/c\"${distro_id}:${distro_codename}-backports";' /etc/apt/apt.conf.d/50unattended-upgrades
echo "Updates tab has been configured."

read -p "Update? y or n: " ans
if [ "$ans == "y" ]; then
	echo "Installing updates"
	sudo apt update
	sudo apt upgrade
fi

echo "Reboot computer"
