#!/bin/bash
printf "deb http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\ndeb-src http://security.ubuntu.com/ubuntu/ xenial-security main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-updates main universe\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial-backports main universe\n" | sudo tee -a /etc/apt/sources.list
sudo apt-get install unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
clear
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/20auto-upgrades
sudo sed -i '/APT::Periodic::Update-Package-Lists/c\APT::Periodic::Update-Package-Lists "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Download-Upgradeable-Packages/c\APT::Periodic::Download-Upgradeable-Packages "1";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::AutocleanInterval/c\APT::Periodic::AutocleanInterval "7";' /etc/apt/apt.conf.d/10periodic
sudo sed -i '/APT::Periodic::Unattended-Upgrade/c\APT::Periodic::Unattended-Upgrade "1";' /etc/apt/apt.conf.d/10periodic
echo "Updates tab configured."

read -p "Update? y or n: " ans
if [ "$ans == "y" ]; then
	echo "Installing updates"
	sudo apt update
	sudo apt upgrade
fi
