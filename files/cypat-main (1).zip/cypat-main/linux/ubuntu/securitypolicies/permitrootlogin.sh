#!/bin/bash
read -p "Permit users to login to root account? y or n: " ans
case "$ans" in
        n) sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/usr/sbin/nologin' /etc/passwd
           echo "Disabled root login"
        ;;
        y) echo "Root login will be permitted."
        sudo sed -i '/root:x:0:0/c\root:x:0:0:root:/root:/bin/bash' /etc/passwd
esac
