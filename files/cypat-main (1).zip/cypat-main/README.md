# CyberPatriot Scripts

# Linux Scripts

You can download the scripts and as long as you do
`chmod +x file.txt`
and then you can run it by doing
`./file.txt`

This works because of the `#!/bin/sh`

### Account Management Script

Before running the Account management script go to terminal and type:

`gedit readme.txt`

Then copy and paste the CyberPatriot Read Me (only the authorized users and admins) and paste it into the readme.txt

Remove any empty lines from the readme

When running the Account Management script make sure the format of readme.txt is the same as readme.txt

### Password Policies

While running the script if there is an error when downloading the package, go to `Software and Updates > Ubuntu Software` and check the following boxes

1. Canonical-supported free and open-source software (main)
2. Community-maintained free and open-source software (universe)
3. Proprietary drivers for devices (restricted)
4. Software resitrcted by copyright or legal issues (multiverse)

Remember to disable after you run the script

# Windows Scripts

### Account Management

When importing script to VM, make sure to run the script as an administrator

`desiredusers.txt` should look exactly like `readme.txt` (an example can be found in `linux/passwordpolicy`)

Before running the script, run Windows Powershell as Administrator and type in the following command

`Set-ExecutionPolicy Unrestricted`

### Security Policies

Local Security Policy Template: SetLocalSecPols.inf
1. Connect flashdrive to vm OR download from github
2. Open Local Securty Policy on vm
3. Local Security Policy → Right click “Security Settings” → Import Policy
3. Navigate to flashdrive or where file is downloaded
4. Click "Open"
